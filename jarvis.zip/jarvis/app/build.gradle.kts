plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "uz.jarvis"
    compileSdk = 34
    defaultConfig { applicationId = "uz.jarvis"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("ai.picovoice:porcupine-android:3.0.2")
}
