package uz.jarvis

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.*

object NotifStore {
    private val list = ArrayDeque<String>()
    @Synchronized fun add(s: String) {
        if (list.firstOrNull()?.substringAfter("] ") == s.substringAfter("] ")) return
        list.addFirst(s); while (list.size > 25) list.removeLast()
    }
    @Synchronized fun recent() = if (list.isEmpty()) "yo'q" else list.take(15).joinToString("\n")
}

class NotifService : NotificationListenerService() {
    override fun onListenerConnected() { activeNotifications?.forEach { fmt(it) } }
    override fun onNotificationPosted(s: StatusBarNotification) { fmt(s) }
    private fun fmt(s: StatusBarNotification) {
        if (s.packageName == packageName || s.isOngoing) return
        val e = s.notification.extras
        val t = e.getCharSequence("android.title") ?: return
        val x = e.getCharSequence("android.text") ?: ""
        val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(s.packageName, 0)) } catch (_: Exception) { s.packageName }
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.postTime))
        NotifStore.add("[$time] $app: $t: $x")
    }
}
