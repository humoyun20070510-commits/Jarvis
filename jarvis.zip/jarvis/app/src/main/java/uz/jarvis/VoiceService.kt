package uz.jarvis

import ai.picovoice.porcupine.Porcupine
import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.media.*
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

/**
 * Mikrofon doim ochiq (uzilmaydi, "ding" yo'q). Porcupine "Jarvis"ni telefonning o'zida
 * bir zumda aniqlaydi, keyin buyruq ovozi to'g'ridan-to'g'ri Gemini'ga yuboriladi.
 */
class VoiceService : Service(), TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private var wl: PowerManager.WakeLock? = null
    @Volatile private var running = true
    @Volatile private var busy = false
    @Volatile private var forceListen = false
    @Volatile private var nextForce = false
    @Volatile private var pending: JSONArray? = null
    private val tone by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 80) }

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:wl").apply { acquire() }
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("j", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "j").setContentTitle("Jarvis eshitmoqda")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        tts = TextToSpeech(this, this)
        Thread { loop() }.start()
    }

    override fun onInit(s: Int) {
        var lr = tts.setLanguage(Locale("uz", "UZ"))
        if (lr < 0) {
            lr = tts.setLanguage(Locale("tr", "TR"))
            if (lr < 0) tts.setLanguage(Locale.getDefault())
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { finish() }
            override fun onDone(id: String?) { finish() }
        })
    }

    private fun beep() { try { tone.startTone(ToneGenerator.TONE_PROP_ACK, 150) } catch (_: Exception) {} }

    private fun rms(b: ShortArray, n: Int): Double {
        var s = 0.0
        for (i in 0 until n) s += b[i].toDouble() * b[i]
        return Math.sqrt(s / n)
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("pico", "") ?: ""
        val porc: Porcupine? = try {
            Porcupine.Builder().setAccessKey(key).setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.8f).build(applicationContext)
        } catch (e: Exception) { Dbg.add("Porcupine xatosi: ${e.message}"); null }
        if (porc == null) {
            main.post { Toast.makeText(this, "Picovoice kalit noto'g'ri. Jurnalga qarang.", Toast.LENGTH_LONG).show(); stopSelf() }
            return
        }
        val rate = 16000
        val frame = porc.frameLength
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, frame * 8))
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Dbg.add("Mikrofon ochilmadi (ruxsat yoki band)")
            porc.delete(); main.post { stopSelf() }; return
        }
        rec.startRecording()
        Dbg.add("Tayyor: 'Jarvis' deng")
        val buf = ShortArray(frame)
        val pcm = ByteArrayOutputStream()
        var listening = false
        var t0 = 0L; var lastVoice = 0L; var speech = false
        var thr = 700.0; var idle = 300.0
        while (running) {
            val n = rec.read(buf, 0, frame)
            if (n <= 0) { Thread.sleep(20); continue }
            if (n < frame || busy) continue
            val r = rms(buf, n)
            if (!listening) {
                var start = false
                if (forceListen) { forceListen = false; start = true; beep() }
                else {
                    idle = idle * 0.98 + r * 0.02
                    val idx = try { porc.process(buf) } catch (e: Exception) { -1 }
                    if (idx >= 0) { Dbg.add("Jarvis eshitildi"); beep(); start = true }
                }
                if (start) {
                    listening = true; pcm.reset(); speech = false
                    t0 = System.currentTimeMillis(); lastVoice = t0
                    thr = maxOf(650.0, idle * 2.5)
                }
            } else {
                val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until n) bb.putShort(buf[i])
                pcm.write(bb.array())
                val now = System.currentTimeMillis()
                if (now - t0 > 300 && r > thr) { speech = true; lastVoice = now }
                val done = (speech && now - lastVoice > 1100) || (!speech && now - t0 > 5000) || (now - t0 > 12000)
                if (done) {
                    listening = false
                    busy = true
                    val wav = if (speech) Wav.wrap(pcm.toByteArray(), rate) else null
                    Thread { handleAudio(wav) }.start()
                }
            }
        }
        try { rec.stop() } catch (_: Exception) {}
        rec.release(); porc.delete()
    }

    private fun handleAudio(wav: ByteArray?) {
        try {
            if (wav == null) { Dbg.add("Gap eshitilmadi"); pending = null; finish(); return }
            val p = pending
            if (p != null) {
                pending = null
                val yes = Brain.confirm(this, wav)
                Dbg.add("Tasdiq: $yes")
                if (yes) { val e = runActions(p); speak(e ?: "Bajarildi") } else speak("Bekor qilindi")
                return
            }
            val r = Brain.ask(this, null, wav)
            Dbg.add("Javob: $r")
            val acts = r.optJSONArray("actions")
            val say = r.optString("say")
            val confirm = r.optBoolean("confirm") && acts != null && acts.length() > 0
            var err: String? = null
            if (confirm) pending = acts else if (acts != null) err = runActions(acts)
            val out = err ?: say
            if (out.isNotBlank()) speak(out, confirm) else finish()
        } catch (e: Exception) {
            Dbg.add("Xato: ${e.message}"); finish()
        }
    }

    private fun runActions(acts: JSONArray): String? {
        var err: String? = null
        for (k in 0 until acts.length()) {
            val e = Actions.run(this, acts.getJSONObject(k))
            if (e != null && err == null) err = e
            Thread.sleep(500)
        }
        return err
    }

    /** Worker oqimidan chaqiriladi */
    private fun speak(t: String, askNext: Boolean = false) {
        nextForce = askNext
        main.post { Toast.makeText(this, "Jarvis: $t", Toast.LENGTH_SHORT).show() }
        if (!Voice.say(this, t)) Dbg.add("Ovoz chiqmadi, javob matn ko'rinishida: $t")
        finish()
    }

    private fun finish() {
        main.postDelayed({ forceListen = nextForce; nextForce = false; busy = false }, 350)
    }

    override fun onDestroy() {
        running = false
        tts.shutdown(); wl?.release()
        super.onDestroy()
    }
}
