package uz.jarvis

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Phone

object Util {
    private val map = mapOf('а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "yo",
        'ж' to "j", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o",
        'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "x", 'ц' to "ts", 'ч' to "ch",
        'ш' to "sh", 'щ' to "sh", 'ъ' to "", 'ы' to "i", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya",
        'ў' to "o", 'қ' to "q", 'ғ' to "g", 'ҳ' to "h")

    /** Kirill -> Lotin, apostroflarni birxillashtiradi */
    fun latin(s: String): String {
        val sb = StringBuilder()
        for (c in s.lowercase()) sb.append(map[c] ?: c.toString())
        return sb.toString().replace(Regex("[’ʻʼ`‘]"), "'")
    }

    fun lev(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }

    /** Kontaktni nomi bo'yicha topadi (lotin/kirill farqisiz) */
    fun findNumber(ctx: Context, name: String): String? {
        val q = latin(name).replace("'", "").trim()
        if (q.isEmpty()) return null
        var partial: String? = null
        ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val n = latin(c.getString(0) ?: "").replace("'", "")
                val num = c.getString(1) ?: continue
                if (n == q) return num
                if (partial == null && n.isNotEmpty() && (n.contains(q) || q.contains(n))) partial = num
            }
        }
        return partial
    }
}
