package uz.jarvis

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit

object Wav {
    fun wrap(pcm: ByteArray, rate: Int): ByteArray {
        val o = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        o.put("RIFF".toByteArray()); o.putInt(36 + pcm.size); o.put("WAVE".toByteArray())
        o.put("fmt ".toByteArray()); o.putInt(16); o.putShort(1.toShort()); o.putShort(1.toShort())
        o.putInt(rate); o.putInt(rate * 2); o.putShort(2.toShort()); o.putShort(16.toShort())
        o.put("data".toByteArray()); o.putInt(pcm.size); o.put(pcm)
        return o.array()
    }
}

/** Gemini orqali o'zbekcha ovoz. Telefon ovoziga o'tmaydi: ishlamasa matn ekranda ko'rinadi. */
object Voice {
    private val http = OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build()
    private val off = HashMap<String, Long>()

    fun say(ctx: Context, text: String): Boolean {
        val p = ctx.getSharedPreferences("j", Context.MODE_PRIVATE)
        val key = p.getString("key", "") ?: ""
        if (key.isBlank()) return false
        val custom = p.getString("ttsmodel", "") ?: ""
        val models = if (custom.isBlank())
            listOf("gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts", "gemini-2.5-flash-preview-tts") else listOf(custom)
        for (m in models) {
            if (System.currentTimeMillis() < (off[m] ?: 0L)) continue
            if (one(key, m, text)) return true
        }
        return false
    }

    private fun one(key: String, model: String, text: String): Boolean {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", "Kore")))))
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        return try {
            http.newCall(req).execute().use { r ->
                val raw = r.body?.string() ?: ""
                if (!r.isSuccessful) {
                    Dbg.add("Ovoz HTTP ${r.code} ($model): ${raw.take(160)}")
                    off[model] = System.currentTimeMillis() + if (r.code == 429) 60000L else 300000L
                    return@use false
                }
                val b64 = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                    .getJSONObject("inlineData").getString("data")
                play(Base64.decode(b64, Base64.DEFAULT))
                true
            }
        } catch (e: Exception) {
            Dbg.add("Ovoz xatosi ($model): ${e.message}")
            off[model] = System.currentTimeMillis() + 60000L
            false
        }
    }

    private fun play(pcm: ByteArray) {
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size).setTransferMode(AudioTrack.MODE_STATIC).build()
        at.write(pcm, 0, pcm.size)
        at.play()
        Thread.sleep(pcm.size / 2 * 1000L / 24000 + 250)
        at.release()
    }
}
