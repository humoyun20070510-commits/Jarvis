package uz.jarvis

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.telecom.TelecomManager
import org.json.JSONObject

object Actions {
    private val pk = mapOf(
        "instagram" to "com.instagram.android", "telegram" to "org.telegram.messenger",
        "youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp",
        "tiktok" to "com.zhiliaoapp.musically", "chrome" to "com.android.chrome")
    private val SEND = arrayOf("send", "yuborish", "yubor", "отправить")
    private const val NEW = Intent.FLAG_ACTIVITY_NEW_TASK

    fun run(ctx: Context, a: JSONObject): String? {
        val acc = JarvisAccessibility.instance
        val t = a.optString("type")
        if (t in setOf("like", "next", "prev", "click", "type", "back", "home", "global", "telegram") && acc == null) {
            Dbg.add("$t: Accessibility o'chiq")
            return "Accessibility yoqilmagan, sozlamalarda Jarvisni yoqing"
        }
        var err: String? = null
        try {
            when (t) {
                "call" -> {
                    val n = Util.findNumber(ctx, a.optString("name"))
                    if (n == null) err = "Kontakt topilmadi"
                    else ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))).addFlags(NEW))
                }
                "answer" -> ctx.getSystemService(TelecomManager::class.java).acceptRingingCall()
                "hangup" -> @Suppress("DEPRECATION") ctx.getSystemService(TelecomManager::class.java).endCall()
                "open_app" -> if (!open(ctx, a.optString("app"))) err = "Ilova topilmadi"
                "reels" -> {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/reels/"))
                            .setPackage("com.instagram.android").addFlags(NEW))
                    } catch (e: Exception) {
                        if (!open(ctx, "instagram")) err = "Instagram topilmadi"
                        else if (!(acc?.clickDesc("reels") ?: false)) acc?.clickText("reels")
                    }
                }
                "like" -> if (!(acc?.clickDesc("like", "yoqdi", "нравится") ?: false)) err = "Like tugmasi topilmadi"
                "next" -> acc?.swipe(true)
                "prev" -> acc?.swipe(false)
                "click" -> if (!(acc?.clickText(a.optString("text")) ?: false)) err = "Ekranda topilmadi"
                "type" -> if (!(acc?.setText(a.optString("text")) ?: false)) err = "Yozish maydoni topilmadi"
                "back" -> acc?.back()
                "home" -> acc?.home()
                "global" -> acc?.global(a.optString("what"))
                "sms" -> {
                    val n = Util.findNumber(ctx, a.optString("name"))
                    if (n == null) err = "Kontakt topilmadi"
                    else {
                        val sm = ctx.getSystemService(android.telephony.SmsManager::class.java)
                        sm.sendMultipartTextMessage(n, null, sm.divideMessage(a.optString("text")), null, null)
                    }
                }
                "whatsapp" -> whatsapp(ctx, a.optString("name"), a.optString("text"))
                "telegram" -> telegram(ctx, a.optString("name"), a.optString("text"))
                "volume" -> {
                    val am = ctx.getSystemService(AudioManager::class.java)
                    val d = when (a.optString("dir")) { "up" -> AudioManager.ADJUST_RAISE; "down" -> AudioManager.ADJUST_LOWER; else -> AudioManager.ADJUST_TOGGLE_MUTE }
                    repeat(if (d == AudioManager.ADJUST_TOGGLE_MUTE) 1 else 3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI) }
                }
                "flashlight" -> {
                    val cm = ctx.getSystemService(CameraManager::class.java)
                    val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    cm.setTorchMode(id, a.optBoolean("on", true))
                }
                "alarm" -> ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis")).putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(NEW))
                "timer" -> ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60)).putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(NEW))
                "web" -> ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))).addFlags(NEW))
                "youtube" -> {
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query")))).addFlags(NEW)
                    try { ctx.startActivity(Intent(i).setPackage("com.google.android.youtube")) } catch (_: Exception) { ctx.startActivity(i) }
                }
                "navigate" -> {
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(a.optString("place")))).addFlags(NEW)
                    try { ctx.startActivity(Intent(i).setPackage("com.google.android.apps.maps")) } catch (_: Exception) { ctx.startActivity(i) }
                }
            }
        } catch (e: SecurityException) {
            Dbg.add("Amal $t: ruxsat yo'q (${e.message})")
            return "Ruxsat berilmagan, ilovada 1-tugmani bosing"
        } catch (e: Exception) {
            Dbg.add("Amal $t xato: ${e.message}")
            return "Bajara olmadim"
        }
        Dbg.add("Amal $t: " + (err ?: "OK"))
        return err
    }

    private fun open(ctx: Context, name: String): Boolean {
        val n = name.lowercase()
        var pkg = pk[n]
        if (pkg == null) {
            val pm = ctx.packageManager
            pkg = pm.getInstalledApplications(0).firstOrNull {
                Util.latin(pm.getApplicationLabel(it).toString()).contains(Util.latin(n))
            }?.packageName
        }
        val p = pkg ?: return false
        val li = ctx.packageManager.getLaunchIntentForPackage(p) ?: return false
        ctx.startActivity(li.addFlags(NEW))
        JarvisAccessibility.instance?.waitFor(p, 4000) ?: Thread.sleep(1500)
        return true
    }

    private fun whatsapp(ctx: Context, name: String, text: String) {
        var d = (Util.findNumber(ctx, name) ?: return).filter { it.isDigit() }
        if (d.length == 9) d = "998$d"
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$d?text=" + Uri.encode(text)))
            .setPackage("com.whatsapp").addFlags(NEW))
        val acc = JarvisAccessibility.instance ?: return
        acc.waitFor("com.whatsapp", 5000)
        repeat(4) { if (acc.clickDesc(*SEND)) return; Thread.sleep(400) }
    }

    private fun telegram(ctx: Context, name: String, text: String) {
        val acc = JarvisAccessibility.instance ?: return
        open(ctx, "telegram")
        if (!acc.clickDesc("search", "qidirish", "поиск")) return
        Thread.sleep(700); acc.setText(name); Thread.sleep(1400)
        if (!acc.clickText(name)) return
        Thread.sleep(1200); acc.setText(text); Thread.sleep(500)
        acc.clickDesc(*SEND)
    }
}
