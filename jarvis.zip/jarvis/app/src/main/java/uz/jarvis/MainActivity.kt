package uz.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("j", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        val key = EditText(this).apply {
            hint = "Gemini API kalit (AIza...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        val model = EditText(this).apply { hint = "Model (bo'sh = avtomatik)"; setText(prefs.getString("model", "")) }
        val wake = EditText(this).apply { hint = "Chaqiruv so'zi"; setText(prefs.getString("wake", "jarvis")) }
        fun save() = prefs.edit().putString("key", key.text.toString().trim())
            .putString("model", model.text.toString().trim()).putString("wake", wake.text.toString().trim().lowercase().ifBlank { "jarvis" }).apply()
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        root.addView(TextView(this).apply { text = "JARVIS"; textSize = 28f })
        root.addView(key); root.addView(model); root.addView(wake)
        root.addView(btn("1. Ruxsatlarni berish") {
            save()
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG,
                Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        root.addView(btn("2. Accessibility yoqish (Jarvis)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("3. Bildirishnoma ruxsati (Jarvis)") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) })
        root.addView(btn("4. Batareya cheklovini o'chirish") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        root.addView(btn("5. JARVIS'NI ISHGA TUSHIRISH") {
            save()
            stopService(Intent(this, JarvisService::class.java))
            startForegroundService(Intent(this, JarvisService::class.java))
            Toast.makeText(this, "Jarvis ishlayapti!", Toast.LENGTH_LONG).show()
        })
        root.addView(btn("To'xtatish") { stopService(Intent(this, JarvisService::class.java)) })
        root.addView(btn("Gemini'ni tekshirish") {
            save(); Dbg.add("Tekshirilmoqda...")
            Thread { val r = Brain.think(this, "salom, o'zingni qisqa tanishtir"); Dbg.add("Natija: " + r.optString("say")) }.start()
        })
        val log = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        root.addView(log)
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        h.post(object : Runnable { override fun run() { log.text = Dbg.text(); h.postDelayed(this, 1000) } })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
