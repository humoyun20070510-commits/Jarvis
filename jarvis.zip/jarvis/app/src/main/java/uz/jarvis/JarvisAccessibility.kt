package uz.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibility : AccessibilityService() {
    companion object { @Volatile var instance: JarvisAccessibility? = null }
    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(i: android.content.Intent?): Boolean { instance = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun swipe(up: Boolean) = main.post {
        val w = resources.displayMetrics.widthPixels; val h = resources.displayMetrics.heightPixels
        val p = Path()
        if (up) { p.moveTo(w / 2f, h * 0.78f); p.lineTo(w / 2f, h * 0.22f) }
        else { p.moveTo(w / 2f, h * 0.22f); p.lineTo(w / 2f, h * 0.78f) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 140)).build(), null, null)
    }

    /** Ilova ekranga chiqquncha kutadi (tez: har 120ms tekshiradi) */
    fun waitFor(pkg: String, ms: Long): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (rootInActiveWindow?.packageName?.toString() == pkg) { Thread.sleep(350); return true }
            Thread.sleep(120)
        }
        return false
    }

    private fun walk(n: AccessibilityNodeInfo, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (pred(n)) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> walk(c, pred)?.let { return it } }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    fun clickText(t: String): Boolean {
        val q = t.lowercase()
        val root = rootInActiveWindow ?: return false
        val n = walk(root) { !it.isEditable && listOfNotNull(it.text, it.contentDescription).any { s -> s.toString().lowercase().contains(q) } }
        return n?.let { clickNode(it) } ?: false
    }

    /** contentDescription yoki view-id aniq mos kelsa bosadi */
    fun clickDesc(vararg d: String): Boolean {
        val set = d.toSet()
        val root = rootInActiveWindow ?: return false
        val n = walk(root) {
            it.contentDescription?.toString()?.lowercase() in set ||
                it.viewIdResourceName?.substringAfter("/")?.lowercase() in set
        }
        return n?.let { clickNode(it) } ?: false
    }

    fun setText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = walk(root) { it.isEditable } ?: return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun back() { performGlobalAction(GLOBAL_ACTION_BACK) }
    fun home() { performGlobalAction(GLOBAL_ACTION_HOME) }
    fun global(w: String) {
        performGlobalAction(when (w) {
            "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "lock" -> GLOBAL_ACTION_LOCK_SCREEN
            else -> return
        })
    }
}
