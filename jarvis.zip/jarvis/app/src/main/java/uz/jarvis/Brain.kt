package uz.jarvis

import android.content.Context
import android.provider.CallLog
import android.provider.ContactsContract.CommonDataKinds.Phone
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

object Brain {
    private val http = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
    private val hist = ArrayDeque<Pair<String, String>>()
    private var cNames = ""
    private var cAt = 0L

    private const val SYSTEM = """Sen Jarvis, telefon ovozli yordamchisisan. Foydalanuvchi o'zbekcha gapiradi (matn lotin yoki kirill bo'lishi mumkin, ovoz tanish xato qilishi mumkin: ma'nosini tushun). Faqat bitta JSON qaytar, boshqa hech narsa yozma:
{"actions":[...],"say":"qisqa o'zbekcha javob","confirm":false}
actions turlari:
{"type":"call","name":"KONTAKTLAR ro'yxatidagi aniq nom"}
{"type":"answer"} - kelayotgan qo'ng'iroqni ko'tarish; {"type":"hangup"} - tugatish
{"type":"open_app","app":"instagram|telegram|youtube|whatsapp|tiktok|chrome|ilova nomi"}
{"type":"reels"} - Instagram Reels; {"type":"like"} - yoqtirish
{"type":"next"} keyingi video/sahifa (tepaga surish); {"type":"prev"} oldingisi
{"type":"click","text":"ekrandagi yozuv"}; {"type":"type","text":"matn"} - kiritish maydoniga yozish
{"type":"back"}; {"type":"home"}; {"type":"global","what":"screenshot|recents|notifications|lock"}
{"type":"sms","name":"kontakt","text":"matn"}; {"type":"whatsapp","name":"kontakt","text":"matn"}; {"type":"telegram","name":"kontakt","text":"matn"}
{"type":"volume","dir":"up|down|mute"}; {"type":"flashlight","on":true}
{"type":"alarm","hour":7,"minute":30,"label":""}; {"type":"timer","seconds":300}
{"type":"web","query":"..."}; {"type":"youtube","query":"..."}; {"type":"navigate","place":"..."}
Qoidalar:
- Ma'lumot so'ralsa (kim qo'ng'iroq qildi, qanday xabar keldi, o'qib ber, soat nechchi) actions bo'sh [] va "say"ga KONTEKSTdan javob yoz. "O'qib ber" desa xabarlarni o'qi.
- Xabar yuborish (sms, whatsapp, telegram) har doim "confirm":true bilan; "say"da so'ra: "<kimga> <matn> deb yuboraymi?"
- Pul o'tkazish, o'chirish kabi xavfli ishlarda ham confirm:true.
- Qo'ng'iroq uchun kontakt nomini KONTAKTLAR ro'yxatidan aniq tanla.
- say 1-3 qisqa gap, ovozda o'qiladi; emoji va belgilar ishlatma.
- Tushunmasang say'da qisqa aniqlashtir."""

    private fun say(s: String) = JSONObject().put("say", s)

    fun think(ctx: Context, cmd: String): JSONObject {
        val p = ctx.getSharedPreferences("j", Context.MODE_PRIVATE)
        val key = p.getString("key", "") ?: ""
        val model = (p.getString("model", "") ?: "").ifBlank { "gemini-flash-lite-latest" }
        if (key.isBlank()) return say("API kalit kiritilmagan")
        val now = SimpleDateFormat("EEEE dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
        val content = "Hozir: $now\nKONTAKTLAR: ${contacts(ctx)}\nBildirishnomalar:\n${NotifStore.recent()}\nQo'ng'iroqlar:\n${calls(ctx)}\n\nBUYRUQ: $cmd"
        fun part(role: String, t: String) = JSONObject().put("role", role)
            .put("parts", JSONArray().put(JSONObject().put("text", t)))
        val msgs = JSONArray()
        for ((u, a) in hist) { msgs.put(part("user", u)); msgs.put(part("model", a)) }
        msgs.put(part("user", content))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", msgs)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("maxOutputTokens", 400).put("temperature", 0.3))
        val models = if (p.getString("model", "").isNullOrBlank())
            listOf("gemini-flash-lite-latest", "gemini-flash-latest", "gemini-2.5-flash") else listOf(model)
        for (m in models) {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            try {
                val res: JSONObject? = http.newCall(req).execute().use { r ->
                    val raw = r.body?.string() ?: ""
                    if (r.code == 404) return@use null
                    if (!r.isSuccessful) {
                        Dbg.add("HTTP ${r.code} ($m): ${raw.take(220)}")
                        return@use say(when (r.code) {
                            400, 403 -> "API kalit noto'g'ri"
                            429 -> "Bepul limit tugadi, birozdan keyin urinib ko'ring"
                            else -> "Server xatosi ${r.code}" })
                    }
                    try {
                        val txt = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                        val j = JSONObject(txt.substring(txt.indexOf('{'), txt.lastIndexOf('}') + 1))
                        hist.addLast(cmd to j.toString()); while (hist.size > 3) hist.removeFirst()
                        Dbg.add("OK model: $m")
                        j
                    } catch (e: Exception) {
                        Dbg.add("Javobni o'qib bo'lmadi: ${raw.take(220)}")
                        say("Javobni tushunmadim")
                    }
                }
                if (res != null) return res
                Dbg.add("Model topilmadi: $m")
            } catch (e: Exception) {
                Dbg.add("Tarmoq xatosi: ${e.message}")
                return say("Internetda muammo bor")
            }
        }
        return say("Model topilmadi, ilovada model nomini yozing")
    }

    private fun contacts(ctx: Context): String {
        if (System.currentTimeMillis() - cAt < 60000 && cNames.isNotEmpty()) return cNames
        val s = LinkedHashSet<String>()
        try {
            ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME), null, null, "${Phone.DISPLAY_NAME} ASC")
                ?.use { while (it.moveToNext() && s.size < 300) it.getString(0)?.let { n -> s.add(n) } }
        } catch (_: Exception) {}
        cNames = s.joinToString(", ").ifBlank { "yo'q" }; cAt = System.currentTimeMillis()
        return cNames
    }

    private fun calls(ctx: Context): String = try {
        val sb = StringBuilder()
        val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        ctx.contentResolver.query(CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE),
            null, null, "${CallLog.Calls.DATE} DESC")?.use { c ->
            var n = 0
            while (c.moveToNext() && n++ < 8) {
                val type = when (c.getInt(2)) { 1 -> "kirgan"; 2 -> "chiqqan"; 3 -> "javobsiz"; else -> "boshqa" }
                sb.append("${c.getString(0) ?: c.getString(1)} - $type - ${fmt.format(Date(c.getLong(3)))}\n")
            }
        }
        sb.toString().ifBlank { "yo'q" }
    } catch (e: Exception) { "ruxsat yo'q" }
}
