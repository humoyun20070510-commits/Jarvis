package uz.jarvis

import android.content.Context
import android.provider.CallLog
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.util.Base64
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

object Brain {
    private val http = OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build()
    private val hist = ArrayDeque<Pair<String, String>>()
    private var cNames = ""
    private var cAt = 0L

    private class Res(val text: String?, val err: String?)

    private const val SYSTEM = """Sen Jarvis, telefon ovozli yordamchisisan. Foydalanuvchi o'zbekcha gapiradi. Buyruq matn yoki AUDIO (o'zbekcha ovoz) ko'rinishida keladi; audioni diqqat bilan tingla, "Jarvis" so'zini e'tiborsiz qoldir. Faqat bitta JSON qaytar, boshqa hech narsa yozma:
{"heard":"foydalanuvchi aytgan gap (audio bo'lsa matnga o'gir)","actions":[...],"say":"qisqa o'zbekcha javob (lotin yozuvida)","confirm":false}
actions turlari:
{"type":"call","name":"KONTAKTLAR ro'yxatidagi aniq nom"}
{"type":"answer"} - kelayotgan qo'ng'iroqni ko'tarish; {"type":"hangup"} - tugatish
{"type":"open_app","app":"instagram|telegram|youtube|whatsapp|tiktok|chrome|ilova nomi"}
{"type":"reels"} - Instagram Reels; {"type":"like"} - yoqtirish
{"type":"next"} keyingi video/sahifa (tepaga surish); {"type":"prev"} oldingisi
{"type":"click","text":"ekrandagi yozuv"}; {"type":"type","text":"matn"} - kiritish maydoniga yozish
{"type":"back"}; {"type":"home"}; {"type":"global","what":"screenshot|recents|notifications|lock"}
{"type":"sms","name":"kontakt","text":"matn"}; {"type":"whatsapp","name":"kontakt","text":"matn"}; {"type":"telegram","name":"kontakt","text":"matn"}
{"type":"volume","dir":"up|down|mute"}; {"type":"flashlight","on":true}
{"type":"alarm","hour":7,"minute":30,"label":""}; {"type":"timer","seconds":300}
{"type":"web","query":"..."}; {"type":"youtube","query":"..."}; {"type":"navigate","place":"..."}
Qoidalar:
- Ma'lumot so'ralsa (kim qo'ng'iroq qildi, qanday xabar keldi, o'qib ber, soat nechchi) actions bo'sh [] va "say"ga KONTEKSTdan javob yoz.
- Umumiy savollarga (bilim, maslahat, hisob-kitob) o'zing aniq va qisqa javob ber, actions bo'sh.
- Xabar yuborish (sms, whatsapp, telegram) har doim "confirm":true bilan; "say"da so'ra: "<kimga> <matn> deb yuboraymi?"
- Pul o'tkazish, o'chirish kabi xavfli ishlarda ham confirm:true.
- Qo'ng'iroq uchun kontakt nomini KONTAKTLAR ro'yxatidan aniq tanla.
- say 1-3 qisqa gap, ovozda o'qiladi; emoji, yulduzcha va belgilar ishlatma.
- Audioda gap bo'lmasa yoki umuman tushunarsiz bo'lsa: actions [] va say ""."""

    private fun say(s: String) = JSONObject().put("say", s)

    private fun audioPart(wav: ByteArray) = JSONObject().put("inline_data",
        JSONObject().put("mime_type", "audio/wav").put("data", Base64.encodeToString(wav, Base64.NO_WRAP)))

    private fun textPart(t: String) = JSONObject().put("text", t)

    private fun msg(role: String, parts: JSONArray) = JSONObject().put("role", role).put("parts", parts)

    private fun post(ctx: Context, system: String?, contents: JSONArray, maxTokens: Int): Res {
        val p = ctx.getSharedPreferences("j", Context.MODE_PRIVATE)
        val key = p.getString("key", "") ?: ""
        if (key.isBlank()) return Res(null, "API kalit kiritilmagan")
        val custom = p.getString("model", "") ?: ""
        val models = if (custom.isBlank()) listOf("gemini-flash-lite-latest", "gemini-flash-latest", "gemini-2.5-flash") else listOf(custom)
        val body = JSONObject().put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json")
                .put("maxOutputTokens", maxTokens).put("temperature", 0.3))
        if (system != null) body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(textPart(system))))
        for (m in models) {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            try {
                val res: Res? = http.newCall(req).execute().use { r ->
                    val raw = r.body?.string() ?: ""
                    if (r.code == 404 || r.code == 429) {
                        Dbg.add("HTTP ${r.code} ($m), keyingi model...")
                        return@use null
                    }
                    if (!r.isSuccessful) {
                        Dbg.add("HTTP ${r.code} ($m): ${raw.take(220)}")
                        return@use Res(null, if (r.code == 400 || r.code == 403) "API kalit noto'g'ri" else "Server xatosi ${r.code}")
                    }
                    try {
                        val txt = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                        Dbg.add("OK model: $m")
                        Res(txt, null)
                    } catch (e: Exception) {
                        Dbg.add("Javobni o'qib bo'lmadi: ${raw.take(220)}")
                        Res(null, "Javobni tushunmadim")
                    }
                }
                if (res != null) return res
            } catch (e: Exception) {
                Dbg.add("Tarmoq xatosi: ${e.message}")
                return Res(null, "Internetda muammo bor")
            }
        }
        return Res(null, "Bepul limit tugagan bo'lishi mumkin, birozdan keyin urinib ko'ring")
    }

    private fun parse(txt: String): JSONObject = JSONObject(txt.substring(txt.indexOf('{'), txt.lastIndexOf('}') + 1))

    fun think(ctx: Context, cmd: String): JSONObject = ask(ctx, cmd, null)

    /** cmd (matn) yoki wav (ovoz) beriladi. Ovoz bo'lsa Gemini o'zi tushunadi va bajaradi. */
    fun ask(ctx: Context, cmd: String?, wav: ByteArray?): JSONObject {
        val now = SimpleDateFormat("EEEE dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
        val head = "Hozir: $now\nKONTAKTLAR: ${contacts(ctx)}\nBildirishnomalar:\n${NotifStore.recent()}\nQo'ng'iroqlar:\n${calls(ctx)}\n\n"
        val parts = JSONArray().put(textPart(head + if (cmd != null) "BUYRUQ: $cmd" else "BUYRUQ: quyidagi audioda"))
        if (wav != null) parts.put(audioPart(wav))
        val contents = JSONArray()
        for ((u, a) in hist) { contents.put(msg("user", JSONArray().put(textPart(u)))); contents.put(msg("model", JSONArray().put(textPart(a)))) }
        contents.put(msg("user", parts))
        val r = post(ctx, SYSTEM, contents, 450)
        val txt = r.text ?: return say(r.err ?: "Xato")
        return try {
            val j = parse(txt)
            val heard = j.optString("heard").ifBlank { cmd ?: "(audio)" }
            hist.addLast(heard to j.toString()); while (hist.size > 3) hist.removeFirst()
            j
        } catch (e: Exception) {
            Dbg.add("JSON xato: ${txt.take(200)}")
            say("Javobni tushunmadim")
        }
    }

    /** Ovozli tasdiq: ha / yo'q */
    fun confirm(ctx: Context, wav: ByteArray): Boolean {
        val q = "Audioda foydalanuvchi o'zbekcha tasdiqlayaptimi (ha, yubor, mayli, bo'ladi, albatta) yoki rad etayaptimi (yo'q, kerak emas, bekor)? Faqat JSON: {\"yes\":true} yoki {\"yes\":false}. Tushunarsiz bo'lsa false."
        val contents = JSONArray().put(msg("user", JSONArray().put(textPart(q)).put(audioPart(wav))))
        val r = post(ctx, null, contents, 30)
        val txt = r.text ?: return false
        return try { parse(txt).optBoolean("yes") } catch (e: Exception) { false }
    }

    private fun contacts(ctx: Context): String {
        if (System.currentTimeMillis() - cAt < 60000 && cNames.isNotEmpty()) return cNames
        val s = LinkedHashSet<String>()
        try {
            ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME), null, null, "${Phone.DISPLAY_NAME} ASC")
                ?.use { while (it.moveToNext() && s.size < 300) it.getString(0)?.let { n -> s.add(n) } }
        } catch (_: Exception) {}
        cNames = s.joinToString(", ").ifBlank { "yo'q" }; cAt = System.currentTimeMillis()
        return cNames
    }

    private fun calls(ctx: Context): String = try {
        val sb = StringBuilder()
        val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        ctx.contentResolver.query(CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE),
            null, null, "${CallLog.Calls.DATE} DESC")?.use { c ->
            var n = 0
            while (c.moveToNext() && n++ < 8) {
                val type = when (c.getInt(2)) { 1 -> "kirgan"; 2 -> "chiqqan"; 3 -> "javobsiz"; else -> "boshqa" }
                sb.append("${c.getString(0) ?: c.getString(1)} - $type - ${fmt.format(Date(c.getLong(3)))}\n")
            }
        }
        sb.toString().ifBlank { "yo'q" }
    } catch (e: Exception) { "ruxsat yo'q" }
}
