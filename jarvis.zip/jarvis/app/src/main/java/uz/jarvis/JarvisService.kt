package uz.jarvis

import android.app.*
import android.content.Intent
import android.os.*
import android.speech.*
import android.speech.tts.*
import org.json.JSONArray
import java.util.Locale
import android.widget.Toast

class JarvisService : Service(), TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var wl: PowerManager.WakeLock? = null
    private var awake = false
    @Volatile private var busy = false
    private var pending: JSONArray? = null
    private var wakeWord = "jarvis"

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        wakeWord = Util.latin(getSharedPreferences("j", MODE_PRIVATE).getString("wake", "jarvis") ?: "jarvis")
        wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:wl").apply { acquire() }
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("j", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "j").setContentTitle("Jarvis eshitmoqda")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        tts = TextToSpeech(this, this)
        createSr()
    }

    private fun createSr() {
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) listen() else handle(t)
                }
                override fun onError(e: Int) {
                    if (busy) return
                    if (e != 7 && e != 6) Dbg.add("Tinglash xatosi: $e")
                    if (e == 9) { stopSelf(); return }
                    if (e == 5 || e == 8) createSr()
                    main.postDelayed({ listen() }, if (e == 7 || e == 6) 80 else 400)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
    }

    override fun onInit(s: Int) {
        var lr = tts.setLanguage(Locale("uz", "UZ"))
        if (lr < 0) {
            Dbg.add("O'zbekcha ovoz yo'q, turkcha ishlatilmoqda")
            lr = tts.setLanguage(Locale("tr", "TR"))
            if (lr < 0) tts.setLanguage(Locale.getDefault())
        }
        tts.setSpeechRate(1.1f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { main.post { busy = false; listen() } }
            override fun onDone(id: String?) { main.post { busy = false; listen() } }
        })
        listen()
    }

    private fun listen() {
        if (busy) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L)
        }
        try { sr?.startListening(i) } catch (_: Exception) { createSr(); main.postDelayed({ listen() }, 500) }
    }

    private fun handle(text: String) {
        val low = text.lowercase()
        Dbg.add("Eshitdim: $text")
        Toast.makeText(this, "Eshitdim: $text", Toast.LENGTH_SHORT).show()
        // Tasdiqlash kutilayotgan bo'lsa (xabar yuborish)
        pending?.let { p ->
            pending = null
            val lat = Util.latin(low)
            val no = Regex("(yo'q|yoq|bekor|kerak emas|^no$)").containsMatchIn(lat)
            val yes = Regex("(^| )(ha|xa|yubor|tasdiq\\w*|mayli|bo'ladi|boladi|albatta|ok|okey)( |$)").containsMatchIn(lat)
            if (yes && !no) {
                busy = true
                Thread { runActions(p); main.post { busy = false; speak("Bajarildi") } }.start()
            } else speak("Bekor qilindi")
            return
        }
        // Chaqiruv so'zi (kirill/lotin, 1 harf xatogacha)
        val toks = low.split(Regex("\\s+")).filter { it.isNotBlank() }
        val idx = toks.indexOfFirst { Util.lev(Util.latin(it.filter { c -> c.isLetter() }), wakeWord) <= 1 }
        if (!awake && idx < 0) { listen(); return }
        val cmd = (if (idx >= 0) toks.filterIndexed { i, _ -> i != idx } else toks).joinToString(" ").trim()
        if (cmd.isEmpty()) { awake = true; speak("Eshitaman"); return }
        awake = false
        busy = true
        Thread {
            val r = Brain.think(this, cmd)
            val acts = r.optJSONArray("actions")
            val say = r.optString("say")
            Dbg.add("Javob: $r")
            if (r.optBoolean("confirm") && acts != null && acts.length() > 0) pending = acts
            else if (acts != null) runActions(acts)
            main.post { busy = false; if (say.isNotBlank()) speak(say) else listen() }
        }.start()
    }

    private fun runActions(acts: JSONArray) {
        for (k in 0 until acts.length()) { Actions.run(this, acts.getJSONObject(k)); Thread.sleep(500) }
    }

    private fun speak(t: String) {
        busy = true
        Toast.makeText(this, "Jarvis: $t", Toast.LENGTH_SHORT).show()
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    override fun onDestroy() { sr?.destroy(); tts.shutdown(); wl?.release(); super.onDestroy() }
}
